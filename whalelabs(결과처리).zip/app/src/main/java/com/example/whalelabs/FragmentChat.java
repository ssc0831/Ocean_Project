package com.example.whalelabs;

import androidx.fragment.app.Fragment;

public class FragmentChat extends Fragment {
}
