package com.example.whalelabs;

import android.graphics.Bitmap;
import android.util.Log;

import androidx.lifecycle.ViewModel;


public class WhaleViewModel extends ViewModel{
    private long whaleId;
    private String whaleName;
    private double length;
    private double weight;
    private String content;
    private Bitmap whaleImg;

    private String place;

    public WhaleViewModel(){
        this.whaleId = 1;
        this.whaleName = "상괭이";
        this.place = "목포";
        this.length = 2.1;
        this.weight = 3.3;
        this.content = "상처없음, 숫컷";
        this.whaleImg = null;
    }

    public WhaleViewModel(long whaleId, String whaleName, double length,
                 double weight, String content,
                 Bitmap whaleImg, String place) {
        this.whaleId = whaleId;
        this.whaleName = whaleName;
        this.length = length;
        this.weight = weight;
        this.content = content;
        this.whaleImg = whaleImg;
        this.place = place;
    }

    public void setWhaleViewModel(long whaleId, String whaleName, double length,
                          double weight, String content,
                          Bitmap whaleImg, String place) {

        Log.d("test", "setWhaleViewModel ??"+whaleImg);
        this.whaleId = whaleId;
        this.whaleName = whaleName;
        this.length = length;
        this.weight = weight;
        this.content = content;
        this.whaleImg = whaleImg;
        this.place = place;
    }

    public long getWhaleId() {
        return whaleId;
    }

    public void setWhaleId(long whaleId) {
        this.whaleId = whaleId;
    }

    public String getWhaleName() {
        return whaleName;
    }

    public void setWhaleName(String whaleName) {
        this.whaleName = whaleName;
    }

    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        this.length = length;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Bitmap getWhaleImg() {
        Log.d("test", "getWhaleImg: ");
        return whaleImg;
    }

    public void setWhaleImg(Bitmap whaleImg) {
        Log.d("test", "setWhaleImg: "+whaleImg);
        this.whaleImg = whaleImg;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }
}