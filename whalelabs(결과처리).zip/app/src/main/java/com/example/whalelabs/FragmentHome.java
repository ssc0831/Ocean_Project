package com.example.whalelabs;

import android.Manifest;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.ViewModelProvider;

import com.bumptech.glide.Glide;

import java.io.IOException;
import java.io.Serializable;

public class FragmentHome extends Fragment implements ActivityCompat.OnRequestPermissionsResultCallback {

    private static final int REQUEST_CAMERA = 1;
    private static final int REQUEST_GALLERY = 2;

    private ImageView btnImg, ivWhale, btnSend;
    private EditText etContent, edtPlace, edtLength, edtWeight;
    private Bitmap imageBitmap;
    private WhaleViewModel whaleViewModel;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        btnImg = view.findViewById(R.id.btnImg);
        btnSend = view.findViewById(R.id.btnSend);
        ivWhale = view.findViewById(R.id.ivWhale);
        etContent = view.findViewById(R.id.etContent);
        edtPlace = view.findViewById(R.id.edtPlace);
        edtLength = view.findViewById(R.id.edtLength);
        edtWeight = view.findViewById(R.id.edtWeight);

        whaleViewModel = new ViewModelProvider(requireActivity()).get(WhaleViewModel.class);
        btnImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("test", "onClick: ??");
                showImageSourceDialog();
            }
        });

        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("test", "btnSend onClick: 11"+imageBitmap);
                if (imageBitmap == null)
                    Toast.makeText(requireActivity(), "이미지를 선택해주세요.", Toast.LENGTH_SHORT).show();
                else if (edtPlace.getText().toString().trim().isEmpty())
                    Toast.makeText(requireActivity(), "발견장소를 입력하세요.", Toast.LENGTH_SHORT).show();
                else if(edtLength.getText().toString().trim().isEmpty())
                    Toast.makeText(requireActivity(), "길이를 입력하세요.", Toast.LENGTH_SHORT).show();
                else if (edtWeight.getText().toString().trim().isEmpty())
                    Toast.makeText(requireActivity(), "무게를 입력하세요.", Toast.LENGTH_SHORT).show();
                else if (edtWeight.getText().toString().trim().isEmpty())
                    Toast.makeText(requireActivity(), "무게를 입력하세요.", Toast.LENGTH_SHORT).show();
                else if (etContent.getText().toString().trim().isEmpty())
                    Toast.makeText(requireActivity(), "기타 내용을 입력하세요.", Toast.LENGTH_SHORT).show();
               else{
                    Log.d("test", "btnSend onClick: 22"+edtLength.getText().toString());
                    // 뷰모델에 데이터 설정
                    whaleViewModel.setWhaleViewModel(1, "상괭이",
                            Double.parseDouble(edtLength.getText().toString().trim()),
                            Double.parseDouble(edtWeight.getText().toString().trim()),
                            etContent.getText().toString().trim(),
                            imageBitmap,
                            edtPlace.getText().toString().trim());
                    Toast.makeText(requireActivity(), "전송완료! 결과탭을 확인하세요.", Toast.LENGTH_SHORT).show();
                }
            }
        });
        return view;

    }

    ActivityResultLauncher<Intent> cameraLauncher = registerForActivityResult(
        new ActivityResultContracts.StartActivityForResult(),
        result -> {
            Log.d("test", "cameraLauncher: ??");
            if (result.getResultCode() == Activity.RESULT_OK) {
                Log.d("test", "cameraLauncher: RESULT_OK");
                imageBitmap = (Bitmap) result.getData().getExtras().get("data");
                ivWhale.setImageBitmap(imageBitmap);
                whaleViewModel.setWhaleImg(imageBitmap);
                Log.d("test", "cameraLauncher: "+imageBitmap);
            }

        }
    );

    ActivityResultLauncher<Intent> gelleryLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                Log.d("test", "gelleryLauncher1: ??");
                if (result.getResultCode() == Activity.RESULT_OK) {
                    Log.d("test", "gelleryLauncher1: RESULT_OK");
                    // 갤러리에서 선택한 이미지의 URI를 가져옴
                    Uri uri = result.getData().getData();
                    try {
                        imageBitmap = MediaStore.Images.Media.getBitmap(getContext().getContentResolver(), uri);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                    ivWhale.setImageBitmap(imageBitmap);
                    whaleViewModel.setWhaleImg(imageBitmap);
                    Log.d("test", "gelleryLauncher1: imageBitmap"+imageBitmap);
                }

            }
    );

    private void showImageSourceDialog() {
        Log.d("test", "showImageSourceDialog: ??");
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle("업로드 이미지 선택")
                .setItems(new CharSequence[]{"카메라", "앨범", "취소"}, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0:
                                openCamera();
                                break;
                            case 1:
                                openGallery();
                                break;
                            case 2:
                                dialog.dismiss();
                                break;
                        }
                    }
                })
                .show();
    }
    private void openCamera() {
        Log.d("test", "openCamera: 0");
        int permissionCheck = ContextCompat.checkSelfPermission(requireActivity(), android.Manifest.permission.CAMERA);
        Log.d("test", "openCamera: 1");
        if(permissionCheck== PackageManager.PERMISSION_DENIED){
            Log.d("test", "openCamera: 2");
            Toast.makeText(requireActivity(),"카메라 권한을 허용하신 후 다시 이미지를 선택해주세요.",Toast.LENGTH_SHORT).show();
            // 권한 없음
            ActivityCompat.requestPermissions(requireActivity(),new String[]{android.Manifest.permission.CAMERA},0);

        }else {
            Log.d("test", "openCamera: 3");
            //권한 있음
            Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            if (takePictureIntent.resolveActivity(requireActivity().getPackageManager()) != null) {
                Log.d("test", "takePictureIntent: ??");
                cameraLauncher.launch(takePictureIntent);
            }else Log.d("test", "error: ??"+takePictureIntent);
        }
    }


    private void openGallery() {
        Log.d("test", "openGallery: ??");

        Intent pickPictureintent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

//        if (pickPictureintent.resolveActivity(requireActivity().getPackageManager()) != null) {
//            Log.d("test", "pickPictureintent: ??");
//            gelleryLauncher.launch(pickPictureintent);
//        }else Log.d("test", "error: ??"+pickPictureintent);

        if (pickPictureintent.resolveActivity(requireActivity().getPackageManager()) != null) {
            Log.d("test", "pickPictureintent: ??");
            gelleryLauncher.launch(pickPictureintent);
        }else Log.d("test", "error: ??"+pickPictureintent);
    }
//
//    @Override
//    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
//        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
//        Log.d("test", "권한?: ??");
//        if (requestCode == 0) {
//            if (grantResults[0] == 0) {
//                Toast.makeText(getContext(), "카메라 권한이 승인됨", Toast.LENGTH_SHORT).show();
//            } else {
//                //권한 거절된 경우
//                Toast.makeText(getContext(), "카메라 권한이 거절 되었습니다.카메라를 이용하려면 권한을 승낙하여야 합니다.", Toast.LENGTH_SHORT).show();
//            }
//        }
//    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d("test", "onActivityResult: ??");
        if (resultCode == Activity.RESULT_OK) {
            Log.d("test", "onActivityResult: ok");
            if (requestCode == REQUEST_CAMERA && data != null) {
                Log.d("test", "onActivityResult: Camera");
//                Bundle extras = data.getExtras();
//                Bitmap imageBitmap = (Bitmap) extras.get("data");
//                ivWhale.setImageBitmap(imageBitmap);
            } else if (requestCode == REQUEST_GALLERY && data != null) {
                Log.d("test", "onActivityResult: gallery");
                // Handle the image selected from the gallery
                // You can get the URI of the selected image from data.getData()
                // For example:
                // Uri selectedImageUri = data.getData();
                // Use the URI as needed
            }
        }
    }
    
    
    ////////////////////////////////////////////////////////



    // 권한 체크
    private boolean checkPermission() {
        return ContextCompat.checkSelfPermission(requireActivity(), android.Manifest.permission.READ_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED;
    }

    // 권한 요청
    private void requestPermission() {
        ActivityCompat.requestPermissions(
                requireActivity(),
                new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
               0
        );
    }

    // 권한 요청 결과 처리
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == 0) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openGallery();
            } else {
                // 권한이 거부되었을 때의 처리
            }
        }
    }



}
