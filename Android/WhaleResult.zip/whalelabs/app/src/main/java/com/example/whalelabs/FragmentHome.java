package com.example.whalelabs;

import androidx.fragment.app.Fragment;

public class FragmentHome extends Fragment {

}
