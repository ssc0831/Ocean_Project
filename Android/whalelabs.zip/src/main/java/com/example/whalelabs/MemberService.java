package com.example.whalelabs;

public interface MemberService {
}
