package com.example.whalelabs;

public class MemberClient {
}
