package com.chat.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Table
@Entity
public class ChatMessage {
	  public enum MessageType{
	        ENTER, TALK
	  }
	  
	  private MessageType type;
	  @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	  private Long messageNum;
	  private String roomId;
	  private String sender; // user -> mapping
	  private String message;
	  
}
