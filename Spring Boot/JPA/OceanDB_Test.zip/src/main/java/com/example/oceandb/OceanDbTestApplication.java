package com.example.oceandb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OceanDbTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(OceanDbTestApplication.class, args);
	}

}
